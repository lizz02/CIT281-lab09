Title: Release tracker

Body:
TL;DR: This branch includes planned version updates for our initial game launch.

Planned 🚢 date: TBD

Features:
- [ ] 

Bug fixes:
- 
